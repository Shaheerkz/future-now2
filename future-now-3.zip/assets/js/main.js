 const toChangePath = ()=>{
    window.location.href = "verification.php"
 }
 const toNewPass = ()=>{
    window.location.href = "newPassword.php"
 }